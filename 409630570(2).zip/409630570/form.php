<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="index.ico" rel="shortcut icon"/>
    <title>問卷調查</title>
    <style>
        body{
            background-color:#e1dfdf ;
            margin: 0px;
            font-weight: bold;
        }
        ul{
            list-style: none;
            padding: 0; 
            background-color:rgb(249, 234, 214);
            overflow: hidden;
            text-align: center;

        }
        li{
            float:left;
            border:3px solid;
            margin: 15px;
            box-shadow:7px 7px 5px 1px ;
        }
  
        li a{
            display: block;
            padding: 20px;
            text-decoration: none;
            font-size: 30px;color: black;
            
         }
         li a:hover{
            background-color: #e1dfdf;
            color: rgb(234, 186, 13);
        }
        p{
            font-size:20px;
        }
        span{
            font-size:20px;
        }
        
        
  
    </style>
</head>
<body>
<h1 style="text-align: center;"><img src="index.png" width= 5%><font face="fantasy">PT's Cube Station</font></h1>
   
   <ul>
       <div style="width: 1120px; margin: auto;">
           <li ><a href="index.php"><img src="home.png" width="25px"></a></li>
           <li ><a href="cart.html"><img src="cart.png" width="30px"></a></li>
           <li ><a href="3x3.html">3x3解法</a></li>
           <li ><a href="formula.html">公式庫</a></li>
           <li ><a href="form.php">問卷調查</a></li>
           <li ><a href="class.php">課程報名</a></li>
           <li ><a href="aboutme.php">關於我</a></li>
       </div>
   </ul>


    <?php
        error_reporting(0);
        if($_POST){
            echo'<div style="width: 60vw; margin-left: 20vw; background-color: #D5FCE3; padding: 10px;">
                    <h2 style="text-align: center;">非常感謝您填寫的問卷！</h2>
                    <hr>
                    <div style="margin-left: 5vw;">
                        <h2>您所提供的問卷內容是：</h2>
                        <p>Q1. 您的姓名？：'.@$_POST['q1'].'</p>
                        <p>Q2. 您會解魔術方塊嗎？：'.@$_POST['q2'].'</p>
                        <p>Q3. 您最喜歡玩的方塊種類是？：'.@$_POST['q3'].'</p>
                    </div>
                </div>';
        }
    ?>

    <div style="width: 60vw; margin-left: 20vw;">
        <h1>問卷調查</h1>
        <span>關於魔術方塊的問卷調查！</span>
        <hr>
        <form method="post">
            <div style="border: 1px solid #888; border-radius: 15px; background-color:#EEE;">
                <div style="margin: 15px;">
                    <p>Q1. 請問你的姓名是？</p>
                    <input type="text" name="q1" placeholder="姓名" required>
                </div>
                <br>
                <div style="margin: 15px;">
                    <p>Q2. 你會解魔術方塊嗎？</p>
                    <input type="radio" name="q2" id="q2_1" value="會" required><label for="q2_1"> 會</label>
                    <input type="radio" name="q2" id="q2_0" value="不會" required><label for="q2_0"> 不會</label>
                </div>
                <br>
                <div style="margin: 15px;">
                    <p>Q3. 你最喜歡玩的方塊種類是？</p>
                    <select name="q3">
                        <option sleected value="3x3x3 Cube">3x3x3 Cube</option>
                        <option value="4x4x4 Cube">4x4x4 Cube</option>
                        <option value="5x5x5 Cube">5x5x5 Cube</option>
                    </select>
                </div>
                <br>
                <div style="margin: 15px;">
                    <button type="submit" style="width: 50%; height: 40px; font-size:20px; border: 1px solid blue; border-radius: 5px;">送出問卷</button>
                </div>
            </div><br>
            
        </form>    
        <div style="border: 1px solid #888; border-radius: 15px; background-color:#EEE;">
                <div style="margin: 15px;">
                    <p>了解更多google搜尋:</p>
                    <form action="google.php"  methed="POST">
                        <input type="text" name="google" placeholder="搜尋...魔術方塊" >
                        <input type="submit" value="搜尋" style="font-size:20px; border-radius:5px; " >
                    </form>
                    
                </div>
            </div>
    </div><br><br><br>
</body>
</html>