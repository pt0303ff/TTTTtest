<h1 style="text-align: center;"><img src="index.png" width= 5%><font face="fantasy">PT's Cube Station</font></h1>
   
   <ul>
       <div style="width: 1120px; margin: auto;">
           <li ><a href="index.php"><img src="home.png" width="25px"></a></li>
           <li ><a href="cart.html"><img src="cart.png" width="30px"></a></li>
           <li ><a href="3x3.html">3x3解法</a></li>
           <li ><a href="formula.html">公式庫</a></li>
           <li ><a href="form.php">問卷調查</a></li>
           <li ><a href="class.php">課程報名</a></li>
           <li ><a href="aboutme.php">關於我</a></li>
       </div>
   </ul>