<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="index.ico" rel="shortcut icon"/>
    <title>購物車</title>
    <style>
        body{
            background-color:#e1dfdf ;
            margin: 0px;
            font-weight: bold;
        }
        ul{
            list-style: none;
            padding: 0; 
            background-color:rgb(249, 234, 214);
            overflow: hidden;
            text-align: center;

        }
        li{
            float:left;
            border:3px solid;
            margin: 15px;
            box-shadow:7px 7px 5px 1px ;
        }
  
        li a{
            display: block;
            padding: 20px;
            text-decoration: none;
            font-size: 30px;color: black;
            
         }
         li a:hover{
            background-color: #e1dfdf;
            color: rgb(234, 186, 13);
        }
        p,span{
            font-size:20px;
        }
        #cube{
            width: 200px; ;
        }
        
        
  
    </style>
</head>
<body>
<h1 style="text-align: center;"><img src="index.png" width= 5%><font face="fantasy">PT's Cube Station</font></h1>
   
   <ul>
       <div style="width: 1120px; margin: auto;">
           <li ><a href="index.php"><img src="home.png" width="25px"></a></li>
           <li ><a href="cart.html"><img src="cart.png" width="30px"></a></li>
           <li ><a href="3x3.html">3x3解法</a></li>
           <li ><a href="formula.html">公式庫</a></li>
           <li ><a href="form.php">問卷調查</a></li>
           <li ><a href="class.php">課程報名</a></li>
           <li ><a href="aboutme.php">關於我</a></li>
       </div>
   </ul>
    <?php
            error_reporting(0);
            if($_POST){
                $name=$_POST['q1'];
                $cube1=$_POST['3N'];
                $cube2=$_POST['2N'];
                $cube3=$_POST['skN'];
                $sum=$cube1*500+$cube2*300+$cube3*600;
                echo'<div style="width: 60vw; margin-left: 20vw; background-color: #D5FCE3; padding: 10px;">
                        <h2 style="text-align: center;">非常感謝您訂購方塊，以下是您的訂單！</h2>
                        <hr>
                        <div style="margin-left: 5vw;">
                            <h2>您所訂購的內容是：</h2>
                            <p>您的姓名？：'.@$name.'</p>
                            <p> 訂購的方塊:</p>
                            <p>3x3方塊'.@$cube1.'顆</p>
                            <p>2x2方塊'.@$cube2.'顆</p>
                            <p>skewb方塊'.@$cube3.'顆</p>
                            <p>總計:'.@$sum.'元
                            
                        </div>
                    </div>';
            }
        ?><br>
        <div style="width: 100px; margin:auto; font-size:20px; background-color:#D5FCE3; border-radius:15px; text-align:center;">
            <a href="cart.html" >回上一頁</a>
        </div><br><br><br>
        

</body>
</html>