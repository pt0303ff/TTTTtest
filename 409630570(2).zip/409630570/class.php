<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="index.ico" rel="shortcut icon"/>
    <title>報名課程</title>
    <style>
        body{
            background-color:#e1dfdf ;
            margin: 0px;
            font-weight: bold;
        }
        ul{
            list-style: none;
            padding: 0; 
            background-color:rgb(249, 234, 214);
            overflow: hidden;
            text-align: center;

        }
        li{
            float:left;
            border:3px solid;
            margin: 15px;
            box-shadow:7px 7px 5px 1px ;
        }
  
        li a{
            display: block;
            padding: 20px;
            text-decoration: none;
            font-size: 30px;color: black;
            
         }
         li a:hover{
            background-color: #e1dfdf;
            color: rgb(234, 186, 13);
        }
        p{
            font-size:20px;
        }
        span{
            font-size:20px;
        }
        table, th, td { 
            border: 1px solid black;
            border-collapse: collapse; 
            padding: 5px;
        }
        
        
  
    </style>
</head>
<body>
<h1 style="text-align: center;"><img src="index.png" width= 5%><font face="fantasy">PT's Cube Station</font></h1>
   
   <ul>
       <div style="width: 1120px; margin: auto;">
           <li ><a href="index.php"><img src="home.png" width="25px"></a></li>
           <li ><a href="cart.html"><img src="cart.png" width="30px"></a></li>
           <li ><a href="3x3.html">3x3解法</a></li>
           <li ><a href="formula.html">公式庫</a></li>
           <li ><a href="form.php">問卷調查</a></li>
           <li ><a href="class.php">課程報名</a></li>
           <li ><a href="aboutme.php">關於我</a></li>
       </div>
   </ul>
    
       
    <div style="width: 60vw; margin-left: 20vw;">
        <h1>課程報名</h1>
        <span>想要學魔術方塊嗎？現在就來報名魔術方塊的入門課程吧！！</span>
        <hr>

<?php 
    error_reporting(0);
    if($_POST){

        $cycle['c1'] = "第一梯次 2023/01/05(五) ~ 08(日)";
        $cycle['c2'] = "第二梯次 2023/01/13(五) ~ 15(日)";
        $cycle['c3'] = "第三梯次 2023/01/20(五) ~ 22(日)";

        echo'<div style="padding: 30px; border: 3px solid #888; background-color:#EEE;">
            <h2 style="text-align: center; color:green;">您已經完成課程報名，我們將會盡快與您聯繫，請靜待等候。</h2>
            <p>以下是您報名時所填寫的表單內容，請您再次確認！</p>    
            
            <table style="width: 100%">
                <tbody>
                    <tr>
                        <td style="width: 20%">姓名</td>
                        <td>'.$_POST['name'].'</td>
                    </tr>

                    <tr>
                        <td style="width: 20%">電話</td>
                        <td>'.$_POST['phone'].'</td>
                    </tr>

                    <tr>
                        <td style="width: 20%">學生年齡</td>
                        <td>'.$_POST['age'].'</td>
                    </tr>

                    <tr>
                        <td style="width: 20%">學生性別</td>
                        <td>'.$_POST['gender'].'</td>
                    </tr>

                    <tr>
                        <td style="width: 20%">上課梯次</td>
                        <td>'.$cycle[$_POST['cycle']].'</td>
                    </tr>

                </tbody>
            </table>
            <br>';
            
    }

    if(!$_POST){
    echo'<form method="post">
        <div style="border: 1px solid #888; border-radius: 15px; background-color:#EEE;">
            <div style="margin: 15px;">
                <p>姓名</p>
                <input type="text" name="name" placeholder="姓名" required>
            </div>
            <div style="margin: 15px;">
                <p>連絡電話</p>
                <input type="number" name="phone" placeholder="電話" required>
            </div>
            <div style="margin: 15px;">
                <p>學生年齡</p>
                <input type="number" name="age" placeholder="年齡" required>
            </div>
            <div style="margin: 15px;">
                <p>學生性別</p>
                <input type="radio" name="gender" id="gender_m" value="男" require><label for="gender_m"> 男</label>
                <input type="radio" name="gender" id="gender_f" value="女" require><label for="gender_f"> 女</label>
            </div>
            <div style="margin: 15px;">
                <p>上課梯次</p>
                <select name="cycle">
                    <option sleected value="c1">第一梯次 2023/01/05(五) ~ 08(日)</option>
                    <option value="c2">第二梯次 2023/01/13(五) ~ 15(日)</option>
                    <option value="c3">第三梯次 2023/01/20(五) ~ 22(日)</option>
                </select>
            </div>
            <br>
            <div style="margin: 15px;">
                <input type="submit" value="報名課程" style="width: 50%; height: 40px; font-size:20px; border: 1px solid blue; border-radius: 5px;">
            </div>
        </div>
    </form>';
    }
    ?><br>
    <div style="border: 1px solid #888; border-radius: 15px; background-color:#EEE;">
                <div style="margin: 15px;">
                    <p>了解更多google搜尋:</p>
                    <form action="google.php"  methed="POST">
                        <input type="text" name="google" placeholder="搜尋...魔術方塊" >
                        <input type="submit" value="搜尋" style="font-size:20px; border-radius:5px; " >
                    </form>
                    
                </div>
            </div>
    </div><br><br><br>
</body>
</html>