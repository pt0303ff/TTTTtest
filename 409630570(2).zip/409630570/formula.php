<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="index.ico" rel="shortcut icon"/>
    <title>購物車</title>
    <style>
        body{
            background-color:#e1dfdf ;
            margin: 0px;
            font-weight: bold;
        }
        ul{
            list-style: none;
            padding: 0; 
            background-color:rgb(249, 234, 214);
            overflow: hidden;
            text-align: center;

        }
        li{
            float:left;
            border:3px solid;
            margin: 15px;
            box-shadow:7px 7px 5px 1px ;
        }
  
        li a{
            display: block;
            padding: 20px;
            text-decoration: none;
            font-size: 30px;color: black;
            
         }
         li a:hover{
            background-color: #e1dfdf;
            color: rgb(234, 186, 13);
        }
        p,span{
            font-size:20px;
        }
        
        
  
    </style>
</head>
<body>
    <h1 style="text-align: center;"><img src="index.png" width= 5%><font face="fantasy">PT's Cube Station</font></h1>
   
    <ul>
        <div style="width: 1120px; margin: auto;">
            <li ><a href="index.php"><img src="home.png" width="25px"></a></li>
            <li ><a href="cart.html"><img src="cart.png" width="30px"></a></li>
            <li ><a href="3x3.html">3x3解法</a></li>
            <li ><a href="formula.php">公式庫</a></li>
            <li ><a href="form.php">問卷調查</a></li>
            <li ><a href="class.php">課程報名</a></li>
            <li ><a href="aboutme.php">關於我</a></li>
        </div>
    </ul>

    <?php
            error_reporting(0);
            if($_POST){
               
                $oll26=$_POST['oll26'];
                $oll21=$_POST['oll21'];
                $oll45=$_POST['oll45'];
                $pll1=$_POST['pll1'];
                $pll3=$_POST['pll3'];
                $pll8=$_POST['pll8'];
                echo'<div style="width: 60vw; margin-left: 20vw; background-color: #D5FCE3; padding: 10px;">
                        <h2 style="text-align: center;">以下是您喜歡的公式</h2>
                        <hr>
                        <div style="margin-left: 5vw;">
                            <h2>您所選擇的內容是：</h2>
                            <p>喜歡的公式:</p>
                            <p>OLL26:'.@$oll26.'</p>
                            <p>OLL21:'.@$oll21.'</p>
                            <p>OLL45:'.@$oll45.'</p>
                            <p>PLL1:'.@$pll1.'</p>
                            <p>PLL3:'.@$pll3.'</p>
                            <p>PLL8:'.@$pll8.'</p>
                            
                            
                            
                        </div>
                    </div>';
            }
        ?><br>
        <div style="width: 100px; margin:auto; font-size:20px; background-color:#D5FCE3; border-radius:15px; text-align:center;">
            <a href="formula.html" >回上一頁</a>
        </div><br><br><br>
    
       
    

    
</body>
</html>