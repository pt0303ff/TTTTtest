<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="index.ico" rel="shortcut icon"/>
    <title>個人頁面</title>
    <style>
        body{
            background-color:#e1dfdf ;
            margin: 0px;
            font-weight: bold;
        }
        ul{
            list-style: none;
            padding: 0; 
            background-color:rgb(249, 234, 214);
            overflow: hidden;
            text-align: center;

        }
        li{
            float:left;
            border:3px solid;
            margin: 15px;
            box-shadow:7px 7px 5px 1px ;
        }
  
        li a{
            display: block;
            padding: 20px;
            text-decoration: none;
            font-size: 30px;color: black;
            
         }
         li a:hover{
            background-color: #e1dfdf;
            color: rgb(234, 186, 13);
        }
        #php{
            border-radius:15px; 
            border: 2px #888 solid; 
            font-size:20px;
            background-color:#eee;
            padding:10px;
            
        }
        p,span{
            font-size:20px;
        }

        
        
  
    </style>
</head>
<body>
    <h1 style="text-align: center;"><img src="index.png" width= 5%><font face="fantasy">PT's Cube Station</font></h1>
   
    <ul>
        <div style="width: 1120px; margin: auto;">
            <li ><a href="index.php"><img src="home.png" width="25px"></a></li>
            <li ><a href="cart.html"><img src="cart.png" width="30px"></a></li>
            <li ><a href="3x3.html">3x3解法</a></li>
            <li ><a href="formula.html">公式庫</a></li>
            <li ><a href="form.php">問卷調查</a></li>
            <li ><a href="class.php">課程報名</a></li>
            <li ><a href="aboutme.php">關於我</a></li>
        </div>
    </ul>
    <div style="width:60vw; margin-left:20vw;">
        <h1>個人資料</h1>
        <span>我的個人資料&心得</span>
        <hr>
    
        <div id="php">
        <?php
            echo'<table style="width: 800px; padding:10px">

                    <tr>
                        <td><span>班級:資管3C </span></td> 
                        <td><span>學號:409630570 </span></td> 
                        <td><span>姓名:謝承諭</span></td> 
                    </tr>

                    </table>
                    <p>心得:這次不僅使用了html製作網頁，還使用了php程式語言去做互動，
                        成就感又更上一層樓了，而且這次的主題選了自己平常有興趣的東西，做起網頁來會更加得心應手，
                        雖然中途遇到了很多bug及排版設計的地方花了不少時間，但最後都還是得到了滿意的結果，
                        希望之後寫網頁能越來越順手。</p>';
         ?>
        
    </div>
    
    
       
    

    
</body>
</html>