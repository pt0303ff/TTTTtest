<?php
$x=$POST_['$google'];
header("Location:http://www.google.com/search?q=魔術方塊");

?>